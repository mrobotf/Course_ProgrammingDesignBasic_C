#include <stdio.h>
#define PRICE 30
int main()
{
    int num,total;
    num=10;
    total=num*PRICE;
    printf("total=%d",total);

    return 0;
}

#include <stdio.h>
int main(){
    short a,b;
    a=32767;
    b=a+1;
    printf("%hd,%hd\n",a,b);

    return 0;
}

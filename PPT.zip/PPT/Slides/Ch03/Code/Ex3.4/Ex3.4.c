#include <stdio.h>
int main(){
    float a,b;
    a=123456.789e5;
    b=a+20;
    printf("%f",b);

    return 0;
}

#include <stdio.h>
int main()
{
    printf("\n\n12345678901234567890\n");
    printf(" ab c\t de\rf\tg\n");
    printf("h\ti\b\bj k");

    return 0;
}


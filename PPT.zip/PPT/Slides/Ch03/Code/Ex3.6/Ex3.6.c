#include <stdio.h>
int main(){
    char c1,c2;
    c1=97;
    c2=98;
    printf("%c %c\n",c1,c2);
    printf("%d %d\n",c1,c2);

    return 0;
}

#include <stdio.h>
int main(){
    float x;
    int i;
    x=3.6;
    i=(int)x;
    printf("x=%f,i=%d",x,i);

    return 0;
}

#include<stdio.h>
int main(){
   unsigned a;
   int b=-1;
   a=b;
   printf("%u %d\n",b,b);

   return 0;
}

#include <stdio.h>
void main()
{
    int  a,b=2;
    float  data;

    a=1;
    data=(a+b)*1.2;
    printf("data=%f\n",data);
}

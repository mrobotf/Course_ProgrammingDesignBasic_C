#include <stdio.h>
void main(){
    int  a,b=2;
    a=1;
    float  data;
    data=(a+b)*1.2;
    printf("data=%f\n",data);
}

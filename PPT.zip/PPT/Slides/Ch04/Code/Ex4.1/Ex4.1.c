#include <stdio.h>

int main(){
    char a,b,c;
    a='B'; b='O'; c='Y';
    putchar(a);putchar(b);putchar(c);

    return 0;
}

#include <stdio.h>
int main(){
    char c;
    c=getchar();
    putchar(c);

    return 0;
}

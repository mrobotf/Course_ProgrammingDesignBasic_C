#include <stdio.h>
int main(){
    char c;
    c=getch();
    putchar(c);

    return 0;
}

#include <stdio.h>
int main(){
    float score;
    char grade;

    printf("Input your score:");
    scanf("%f",&score);
    switch((int)(score/10))
    {
        case 10:
        case 9:grade='A';
        case 8:grade='B';
        case 7:grade='C';
        case 6:grade='D';
        default:grade='E';
    }
    printf("%f is %c",score,grade);

    return 0;
}

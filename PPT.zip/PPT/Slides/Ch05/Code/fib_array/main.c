#include <stdio.h>

int main(){
    int i;
    long f[40];

    f[0]=1; f[1]=1;
    printf("%d %d ", f[0], f[1]);
    for(i=2;i<40;++i){
        f[i] = f[i-1] + f[i-2];
        printf("%ld ", f[i]);
    }

    return 0;
}

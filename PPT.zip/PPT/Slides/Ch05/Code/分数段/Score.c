#include <stdio.h>
int main(){
    char grade;
    printf("Enter Grade:");
    scanf("%c",&grade);
    switch(grade)
    {
        case 'A':printf("90~100\n");break;
        case 'B':printf("80~89\n");break;
        case 'C':printf("70~80\n");break;
        case 'D':printf("60~69\n");break;
        case 'E':printf("<60\n");break;
        default:printf("error\n");break;
    }

    return 0;
}

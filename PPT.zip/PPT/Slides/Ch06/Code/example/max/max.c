#include <stdio.h>

int main(){
    int a,b,c;
    char choice;
    int bContinue=1;
    int max(int x,int y);

    while(bContinue){
        scanf("%d%d", &a, &b);
        c=max(a,b);
        printf("max=%d\n", c);

        printf("\nContinue?");
        scanf("%*c%c",&choice);
        if (choice=='N' || choice=='n')
            bContinue=0;
    }

    return 0;
}

int max(int x, int y){
    return x>y?x:y;
}

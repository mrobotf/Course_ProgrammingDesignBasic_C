#include <stdio.h>

int main(){
    int a,b,c;
    char choice;
    int bContinue=1;
    int max(int x,int y);

    while(bContinue){
        scanf("%d%d", &a, &b);
        if(a<0 && b<0)
            bContinue=0;
        else{
          c=max(a,b);
          printf("max=%d\n", c);
        }
    }

    return 0;
}

int max(int x, int y){
    return x<y?x:y;
}

#include <stdio.h>
int main()
{
    char c[10]={'I',' ','a','m',' ','a',' ','b','o','y'};
    int i;

    for(i=0;i<10;i++)
      printf("%c",c[i]);
    printf("\n");

    return 0;
}

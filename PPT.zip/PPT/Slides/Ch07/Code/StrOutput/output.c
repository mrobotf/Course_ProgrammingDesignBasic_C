#include <stdio.h>
/* */
void main(){
  char c[]="China";
  char c2[10];

  printf("%s\n",c);
  scanf("%s",c2);
  printf("%s\n",c2);

  getch();
}
/* */
/* /
void main(){
  char str[]="China\nBeijing";
  char str2[32];
  
  puts(str);
  gets(str2);
  printf("%s\n",str2);

  getch();
}
/* */

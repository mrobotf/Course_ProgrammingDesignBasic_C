#include <stdio.h>

#define NUM 45
int main(){
    int fib[NUM];
    int i;

    fib[0]=fib[1]=1;
    for(i=2;i<NUM;i++)
        fib[i] = fib[i-1] + fib[i-2];

    for(i=0;i<NUM;i++){
        if (i%5 == 0)
            printf("\n");
        printf("%12d ", fib[i]);
    }

    return 0;
}

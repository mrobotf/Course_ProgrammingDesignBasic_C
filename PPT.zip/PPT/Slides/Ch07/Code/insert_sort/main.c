#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n=10;
    int nArr[n];
    int i,j,x;

    for(i=0;i<n;i++)
        scanf("%d",&nArr[i]);

    for(i=1;i<n;i++){
        x=nArr[i];
        for(j=i-1;j>=0;j--)
            if(nArr[j]>x)
              nArr[j+1]=nArr[j];
            else break;
        nArr[j+1]=x;
    }

    for(i=0;i<n;i++)
        printf("%d ",nArr[i]);

    return 0;
}

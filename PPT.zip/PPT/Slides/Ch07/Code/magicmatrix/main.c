#include <stdio.h>
#define N 3
int main() {
  int magic_mat[N][N], i, col, row;
  col = (N-1)/2;
  row = 0;
  magic_mat[row][col] = 1;

  for(i = 2; i <= N*N; i++) {
    if((i-1)%N == 0 )  row++;
    else {
      row = (row-1+N)%N;
      col = (col+1) %N;
    }
    magic_mat[row][col] = i;
  }

  for(row = 0; row < N; row++) {
    for(col = 0; col < N; col++)
      printf("%3d",magic_mat[row][col]);
    printf("\n");
  }

  return 0;
}

#include <stdio.h>
#define N 3
#define M 4
#define R 3
int main(){
   int i,j,k;
   int a[N][M]={1,2,3,4,5,6,7,8,9,10,11,12},
        b[M][R]={1,2,3,4,5,6,7,8,9,10,11,12},
        c[N][R]={0};
   for(i=0;i<N;i++)
     for(j=0;j<R;j++){
        for(k=0;k<M;k++)
          c[i][j] += a[i][k]*b[k][j];
     }
   for (i=0;i<N;i++){
      for(j=0;j<R;j++)
         printf("%5d ", c[i][j]);
      printf("\n");
   }
   return 0;
}

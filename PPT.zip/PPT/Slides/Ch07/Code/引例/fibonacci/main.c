#include <stdio.h>

int main(){
    int fib[40];
    int i;

    fib[0]=fib[1]=1;
    for(i=2;i<40;i++)
        fib[i] = fib[i-1] + fib[i-2];

    for(i=0;i<40;i++){
        if (i%5==0)
            printf("\n");
        printf("%12d ", fib[i]);
    }

    return 0;
}

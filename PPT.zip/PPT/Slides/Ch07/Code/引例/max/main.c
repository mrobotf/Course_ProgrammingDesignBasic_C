#include <stdio.h>
#include <stdlib.h>

int main()
{
    int nArr[10];
    int i;

    for(i=0;i<10;i++)
        scanf("%d",&nArr[i]);

    int max=nArr[0];
    for(i=1;i<10;i++)
        if(nArr[i]>max)
            max=nArr[i];

    printf("%d",max);

    return 0;
}

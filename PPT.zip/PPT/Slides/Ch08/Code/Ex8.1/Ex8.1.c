#include <stdio.h>
int main()
{
    printstar();
    print_message();
    printstar();

    return 0;
}

printstar()
{
    printf("******************\n");
}

print_message()
{
    printf("  How do you do!\n");
}

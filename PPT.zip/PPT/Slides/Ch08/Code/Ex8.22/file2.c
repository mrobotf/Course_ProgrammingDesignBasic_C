#include <stdio.h>
extern void enter_string(char str[])
{
    gets(str);
}

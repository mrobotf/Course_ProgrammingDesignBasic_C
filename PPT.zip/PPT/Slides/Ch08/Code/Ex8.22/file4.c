extern void print_string(char str[])
{
    printf("%s\n",str);
}

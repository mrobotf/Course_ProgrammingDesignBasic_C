#include <stdio.h>
void printstar()
{
    printf("********************\n");
}
void print_message()
{
    printf("   How do you do!\n");
}

void main()
{
    printstar();
    print_message();
    printstar();

    getch();
}

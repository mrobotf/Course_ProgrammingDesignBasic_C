#include <stdio.h>
#include <stdlib.h>


struct X{
   unsigned A:1;
   unsigned B:1;
   unsigned C:1;
   unsigned D:1;
   unsigned E:1;
   unsigned F:1;
};


int main()
{
    char i;
    char C1, C2, C3, C4, C5, C6;
    struct X *x;
    char *yes_no[]={"不是案犯", "是案犯"};

    for(i=0;i<64;i++){
      x=(struct X*)(&i);
      C1= x->A || x->B;  C2=(x->A&&x->E) || (x->A&&x->F) || (x->E&&x->F);
      C3=!(x->A&&x->D);  C4=(x->B&&x->C) || (!x->B&&!x->C);
      C5=(x->C&&!x->D) || (!x->C&&x->D);  C6=(!x->D && !x->E) || x->D;

      if(C1 && C2 && C3 && C4 && C5 && C6){
        printf("A%s\n", yes_no[x->A]);
        printf("B%s\n", yes_no[x->B]);
        printf("C%s\n", yes_no[x->C]);
        printf("D%s\n", yes_no[x->D]);
        printf("E%s\n", yes_no[x->E]);
        printf("F%s\n", yes_no[x->F]);
      }
    }
    return 0;
}

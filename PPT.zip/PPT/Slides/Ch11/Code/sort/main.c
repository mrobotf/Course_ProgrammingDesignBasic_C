#include <stdio.h>

struct Student {
  char szName[30], szID[20];
  float fScore;
};
int main() {
  int n, i, j, k;

  scanf("%d",&n);
  struct Student stu[n], tmp;

  for (i=0; i<n; i++)
    scanf("%s%s%f",stu[i].szName,stu[i].szID,&stu[i].fScore);

  for (i=0; i<n-1; i++) {
    k=i;
    for (j=i+1; j<n; j++)
      if(stu[j].fScore>stu[k].fScore)
        k=j;
    tmp=stu[k];
    stu[k]=stu[i];
    stu[i]=tmp;
  }

  for(i=0; i<n; i++)
    printf("%s %s %f\n",stu[i].szName,stu[i].szID,stu[i].fScore);

  return 0;
}

#ifndef LINKLIST_H_INCLUDED
#define LINKLIST_H_INCLUDED

typedef struct student{
  int num;
  float score;
  struct student *next;
} Student, *PStudent;

#endif // LINKLIST_H_INCLUDED

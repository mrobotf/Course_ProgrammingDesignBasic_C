#include <stdio.h>
#include <stdlib.h>

#include "linklist.h"

int main()
{
    Student *head;

    head=create();

    printf("\n\n");
    print(head);

    printf("\n\n");
    insert(head, 10, 98);
    print(head);

    printf("\n\n");
    delete(head, 10);
    print(head);

    return 0;
}



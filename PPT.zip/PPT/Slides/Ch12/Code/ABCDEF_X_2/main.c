#include <stdio.h>
int main() {
  char X, A, B, C, D, E, F, C1, C2, C3, C4, C5, C6;
  char *yes_no[]= {"不是案犯", "是案犯"};
  for (X=0; X<64; X++) {
    A= X & 1;
    B=(X >> 1) & 1;
    C= (X >> 2) & 1;
    D=(X >> 3) & 1;
    E=(X >> 4) & 1;
    F=(X >> 5) & 1;
    C1= A || B;
    C2=(A&&E) || (A&&F) || (E&&F) || (A&&E&&F);
    C3=!(A&&D);
    C4=(B&&C) || (!B&&!C);
    C5=(C&&!D) || (!C&&D);
    C6=(!D && !E) || D;
    if(C1 && C2 && C3 && C4 && C5 && C6) {
      printf("A%s\n", yes_no[A]);
      printf("B%s\n", yes_no[B]);
      printf("C%s\n", yes_no[C]);
      printf("D%s\n", yes_no[D]);
      printf("E%s\n", yes_no[E]);
      printf("F%s\n", yes_no[F]);
    }
  }
  return 0;
}

#include <stdio.h>
int main(){
  int A, B, C, D, E, F;
  int C1,C2,C3,C4,C5,C6;
  char *yes_no[]={"不是案犯","是案犯"};

for(A=0;A<=1;A++)
     for(B=0;B<=1;B++){
        C1= A || B;
        for(C=0;C<=1;C++){
            C4=(B&&C) || (!B&&!C);
           for(D=0;D<=1;D++){
              C3=!(A&&D);
              C5=(C&&!D) || (!C&&D);
              for(E=0;E<=1;E++){
                  C6=(!D && !E) || D;
                 for(F=0;F<=1;F++){
                    C2=(A&&E) || (A&&F) || (E&&F) || (A&&E&&F);
                    if(C1 && C2 && C3 && C4 && C5 && C6){
                      printf("A%s\n", yes_no[A]);
                      printf("B%s\n", yes_no[B]);
                      printf("C%s\n", yes_no[C]);
                      printf("D%s\n", yes_no[D]);
                      printf("E%s\n", yes_no[E]);
                      printf("F%s\n", yes_no[F]);
                   }
                }
               }
             }
        }
     }
   return 0;
}

#include <stdio.h>
typedef struct{
   char name[20];
   int num;
   float fScore;
}Student;
int main(){
  Student stu;
  int n, pos;

  scanf("%d", &n);
  FILE * fp=fopen("stud","rb");
  pos=(n-1)*sizeof(Student);
  fseek(fp, pos, SEEK_SET);
  fread((char*)&stu,sizeof(stu),1,fp);
  printf("%s %d %f", stu.name, stu.num, stu.fScore);
  fclose(fp);
  return 0;
}
